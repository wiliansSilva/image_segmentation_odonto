Imagens selecionadas pelo professor Jonas/UFRGS
